## Azure Cloud Concept Setup and Testing

We have successfully completed the Azure cloud concept setup and testing, deploying and verifying the functionality of virtual machines **VSADP01**, **VSEXP01**, and **VSFSP01** as part of the project’s cloud integration phase.

<img width="900" height="258" alt="image" src="https://github.com/user-attachments/assets/709c06de-5f5d-4808-9175-9177826d29e5" />

<img width="900" height="570" alt="image" src="https://github.com/user-attachments/assets/2b9524a5-a9bf-4cc6-b869-a59ac0babbe9" />

<img width="900" height="459" alt="image" src="https://github.com/user-attachments/assets/b1e1d0f7-391e-4ed0-a8f8-c2e7450b06cf" />

<img width="900" height="528" alt="image" src="https://github.com/user-attachments/assets/be00428e-3cc1-434d-8696-242a82dc31ca" />

<img width="900" height="444" alt="image" src="https://github.com/user-attachments/assets/67c2f0c5-bfaa-4e10-a7e3-0bb5333997b0" />

<img width="900" height="375" alt="image" src="https://github.com/user-attachments/assets/570adc6e-62f2-4974-b0a0-fd89cee63a2f" />

<img width="872" height="546" alt="image" src="https://github.com/user-attachments/assets/70c233c7-fc92-4739-80e3-c596ebfe421a" />
