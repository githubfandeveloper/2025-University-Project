Physical Topology

![Draft_physical_topology](https://github.com/user-attachments/assets/9f386782-fae7-4d98-b549-f093ac746930)
