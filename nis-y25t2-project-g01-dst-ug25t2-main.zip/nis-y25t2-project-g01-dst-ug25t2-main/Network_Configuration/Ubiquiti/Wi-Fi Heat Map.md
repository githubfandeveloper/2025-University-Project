Wi-Fi heat map

<img width="1271" height="586" alt="image" src="https://github.com/user-attachments/assets/5169436a-b74e-4664-97b7-0dd72e48165d" />


<img width="1268" height="587" alt="image" src="https://github.com/user-attachments/assets/a33efd3a-c2cf-4231-a93e-e03b89954a0d" />


<img width="1271" height="588" alt="image" src="https://github.com/user-attachments/assets/20b58219-ac89-4611-9ef7-247180416d1f" />


<img width="1270" height="581" alt="image" src="https://github.com/user-attachments/assets/04fe2bed-f94b-449b-9300-2a32270c5ddd" />

<img width="1270" height="589" alt="image" src="https://github.com/user-attachments/assets/7253b174-79e5-45d8-a0f3-7fdb36d6bd1c" />

